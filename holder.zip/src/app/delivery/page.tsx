export default function App() {
  return (
    <main>
      <div> Delivery </div>
    </main>
  );
}
