/* eslint-disable @typescript-eslint/no-unused-vars */

'use client';

import React, { useEffect } from 'react';

import Link from 'next/link';
// import { fullFavItemTest } from '../api/supabase/queries/tests/user_test';

export default function Checkout() {
  // testFetchUserData();
  // testAddUserAddress();
  // testFetchOrderByUUID();
  // testFetchOrders();
  // testGetOrderById();
  // testToggleOrderProgress();
  // testFetchProducts();
  // testFetchProductByName();
  // testFetchPickupData();
  // testFetchPickupTimesByUUID();
  // testUpdateAllOrdersProgressToTrue();
  // useEffect(() => {
  //   async function testEverything() {
  //     await arrayOfFavorites();
  //   }
  //   testEverything();
  // });

  return (
    <main>
      <Link href="/login">Login</Link>
    </main>
  );
}
