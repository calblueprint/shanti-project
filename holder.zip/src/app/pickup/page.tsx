export default function App() {
  return (
    <main>
      <div> Order Pickup </div>
    </main>
  );
}
